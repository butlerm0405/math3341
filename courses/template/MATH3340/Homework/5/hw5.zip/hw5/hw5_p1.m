% MATH 3340, Semester Year
% Homework 5, Problem 1
% Author: first_name last_name
% Date: mm/dd/yyyy

clear; close all; clc;
% Change default text interpreter to LaTeX
set(groot,'defaultTextInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex')

%% 1(b)
figure(1); hold on;
% Put your code for 1(b) below



%% 1(c)
figure(2); hold on;
% Put your code for 1(c) below


