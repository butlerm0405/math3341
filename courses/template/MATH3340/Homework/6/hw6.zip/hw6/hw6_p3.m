% MATH 3340, Semester Year
% Homework 6, Problem 3
% Author: first_name last_name
% Date: mm/dd/yyyy

clear; close all; clc;
% Change default text interpreter to LaTeX
set(groot,'defaultTextInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex')

figure(1);
% Put your code for 3 for calculating the error of first derivative using central difference below

figure(2);
% Put your code for 3 for calculating the error of second derivative using central difference

