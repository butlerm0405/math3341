% MATH 3340, Semester Year
% Homework 6, Problem 2
% Author: first_name last_name
% Date: mm/dd/yyyy

clear; close all; clc;
% Change default text interpreter to LaTeX
set(groot,'defaultTextInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex')

%% 2(a)
% Put your code for 2(a) below

%% 2(c)
figure(1); hold on;
% Put your code for 2(c) below

