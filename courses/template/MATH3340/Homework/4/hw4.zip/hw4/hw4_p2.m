% MATH 3340, Semester Year
% Homework 4, Problem 2
% Author: first_name last_name
% Date: mm/dd/yyyy

clc; clear;

