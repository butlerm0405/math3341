% MATH 3340, Semester Year
% Homework 4, Problem 3
% Author: first_name last_name
% Date: mm/dd/yyyy

clc; clear;
% change default text interpreter to LaTeX
set(groot,'defaultTextInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex')
figure(3); hold on;

% put your code below
