% Math 3341, Fall 2021
% Lab 06: LU Decomposition
% Author: first_name last_name
% Date: 09/27/2021

clear; close all; clc;
% Change default text interpreter to LaTeX
set(groot, 'defaultTextInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex')
format compact

%% 1 Solve a System with LU Decomposition
% 1(a)

% 1(b)

% 1(c)

% 1(d)

% 1(e)


%% 2 Varying the Vector b
% 2(a)

% 2(b)

% 2(c)

% 2(d)

% 2(e)
