% MATH 3340, Semester Year
% Homework 3, Problem 3
% Author: first_name last_name
% Date: mm/dd/yyyy

clc; clear; figure(3); hold on;

