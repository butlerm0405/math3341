% MATH 3340, Spring 2021
% Final Project Problem 1
% Author: firstname lastname
% Date: mm/dd/yyyy

clear; close all; clc; format short;
% Change default text interpreter to LaTeX
set(groot,'defaultTextInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex')

% PUT YOUR CODE HERE
