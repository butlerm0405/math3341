% MATH 3340, Spring 2021
% Final Project Problem 2
% Author: firstname lastname
% Date: mm/dd/yyyy

clc; clear; figure(3); hold on;
% Change default text interpreter to LaTeX
set(groot,'defaultTextInterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex')

% PUT YOUR CODE HERE
