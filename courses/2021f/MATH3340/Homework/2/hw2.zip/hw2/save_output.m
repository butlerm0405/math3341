diary('hw2_p1.txt')
hw2_p1
diary off
diary('hw2_p2.txt')
hw2_p2
diary off
diary('hw2_p3_a.txt')
hw2_p3_a
diary off
diary('hw2_p3_b.txt')
hw2_p3_b
diary off
diary('hw2_p4.txt')
hw2_p4
diary off
