% MATH 3340, Semester Year
% Homework 2, Problem 1
% Author: first_name last_name
% Date: mm/dd/yyyy

