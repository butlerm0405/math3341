close all; clear; clc;
diary('hw7_p3.txt')
hw7_p3
diary off
