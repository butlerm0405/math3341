% MATH 3340, Semester
% Homework 7, Problem 3
% Author: first_name last_name
% Date: mm/dd/yyyy

clear; close all; clc;

% PUT YOUR CODE HERE
