% MATH 3340, Semester Year
% Homework 8, Problem 2
% Author: first_name last_name
% Date: mm/dd/yyyy

clear; close all; clc;
rng(1204);
% PUT YOUR CODE HERE

