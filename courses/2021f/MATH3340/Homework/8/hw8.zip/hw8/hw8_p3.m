% MATH 3340, Semester Year
% Homework 8, Problem 3
% Author: first_name last_name
% Date: mm/dd/yyyy

clear; close all; clc;
set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
figure(1); hold on;

% PUT YOUR CODE HERE

