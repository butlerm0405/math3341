function f = factorialIterativeBuggy(n)

m = 0;
for i = n
p = p + i;
end

end
