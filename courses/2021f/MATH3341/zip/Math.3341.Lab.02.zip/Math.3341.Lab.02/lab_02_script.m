% Math 3341, Fall 2021
% Lab 02: Variables, Arrays and Scripts
% Author: first_name last_name
% Date: 08/30/2021

clc             % clear command window
clear           % clear variables workspace
format compact  % show results in compact format

%% 1 1-D Array: Vector
% 1(a)

% 1(b)

%% 2 2-D Array: Matrix
% 2(a)

% 2(b)

% 2(c)

% 2(d)

%% 3 Array: Char Array vs. String Array
% 3(a)

% 3(b)

%% 4 Application: Image Processing
% 4(a)

% 4(b)

% 4(c)

