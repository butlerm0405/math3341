% Math 3341, Fall 2021
% Lab 03: Functions and Control Flows
% Author: first_name last_name
% Date: 09/06/2021

clc             % clear command window
clear           % clear variables workspace
format compact  % show results in compact format

%% 1 Anonymous Function

% 1(a)

% 1(b)

% 1(c)

% 1(d)

%% 2 Function Files

% 2(c)

%% 3 Application: Real-Life Problems

% 3(a)

% 3(b)

